Hoyle Playing Card Font Created By David Bradbury a.k.a Conexion
Website: http://conexion.deviantart.com
E-mail: Conexion@Gmail.com

//

For Non-Comercial Use Only. 
Unique Hoyle Symbols/Designs � Hoyle Products 1983
All Rights Reserved

//

--
Keys Used
--

`~1234567890!@#$
qwer
asdf
zxcv

//

Questions or Comments?
E-mail: Conexion@Gmail.com
Thank You for Downloading my Font

--